<?php
$servername = "localhost";
$username = "mvmup_root";
$password = "mvmup@KCIPDE";
$dbname = "mvmup";
?>
